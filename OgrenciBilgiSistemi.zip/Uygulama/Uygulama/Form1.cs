﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Uygulama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label7.Text = "";
            
        }

        OgrenciBilgi ogrenciBilgi = new OgrenciBilgi();

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                ogrenciBilgi.ad = textBox1.Text;
                ogrenciBilgi.no = textBox2.Text;
                ogrenciBilgi.S1 = Convert.ToByte(textBox3.Text);
                ogrenciBilgi.S2 = Convert.ToByte(textBox4.Text);
                ogrenciBilgi.P1 = Convert.ToByte(textBox5.Text);
                ogrenciBilgi.P2 = Convert.ToByte(textBox6.Text);

                label7.Text = ogrenciBilgi.Bilgi();
            }
            catch (Exception kaan)
            {

                MessageBox.Show(kaan.Message, "Hata!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label7.Text = "Hata!";
            }

        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                ogrenciBilgi.ad = textBox1.Text;
                ogrenciBilgi.no = textBox2.Text;
                ogrenciBilgi.S1 = Convert.ToByte(textBox3.Text);
                ogrenciBilgi.S2 = Convert.ToByte(textBox4.Text);
                ogrenciBilgi.P1 = Convert.ToByte(textBox5.Text);
                ogrenciBilgi.P2 = Convert.ToByte(textBox6.Text);

                label7.Text = ogrenciBilgi.Durum();
            }
            catch (Exception kaan)
            {

                MessageBox.Show(kaan.Message, "Hata!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label7.Text = "Hata!";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ogrenciBilgi.ad = textBox1.Text;
                ogrenciBilgi.no = textBox2.Text;
                ogrenciBilgi.S1 = Convert.ToByte(textBox3.Text);
                ogrenciBilgi.S2 = Convert.ToByte(textBox4.Text);
                ogrenciBilgi.P1 = Convert.ToByte(textBox5.Text);
                ogrenciBilgi.P2 = Convert.ToByte(textBox6.Text);

                label7.Text = ogrenciBilgi.Ortalama();
            }
            catch (Exception kaan)
            {

                MessageBox.Show(kaan.Message, "Hata!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                label7.Text = "Hata!";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Kaan Tek";
            textBox2.Text = "498";
            textBox3.Text = "95";
            textBox4.Text = "60";
            textBox5.Text = "70";
            textBox6.Text = "85";

        }
    }
    class OgrenciBilgi
    {
        public string ad = "Girilmedi", no = "Girilmedi";
        byte s1, s2, p1, p2;

        public byte S1
        {
            set
            {
                if (value < 0 || value > 100)
                {
                    MessageBox.Show("Heyy! 0 - 100 arası not girebilirsin.", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    s1 = 0;
                }
                else { s1 = value; }
            }
        }
        public byte S2
        {
            set
            {
                if (value < 0 || value > 100)
                {
                    MessageBox.Show("Heyy! 0 - 100 arası not girebilirsin.", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    s2 = 0;
                }
                else { s2 = value; }
            }
        }
        public byte P1
        {
            set
            {
                if (value < 0 || value > 100)
                {
                    MessageBox.Show("Heyy! 0 - 100 arası not girebilirsin.", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    p1 = 0;
                }
                else { p1 = value; }
            }
        }
        public byte P2
        {
            set
            {
                if (value < 0 || value > 100)
                {
                    MessageBox.Show("Heyy! 0 - 100 arası not girebilirsin.", "Uyarı!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    p2 = 0;
                }
                else { p2 = value; }
            }
        }

        public string Bilgi()
        {
            return string.Format("Öğrenci Bilgisi: {0}\nNo: {1}\nSınav 1: {2}\nSınav 2: {3}\nPerformans 1: {4}\nPerformans 2: {5}", ad, no, s1, s2, p1, p2);
        }
        public string Ortalama()
        {
         
            return string.Format("Öğrenci Bilgisi: {0}\nNo: {1}\nOrtalaması: {2}", ad, no, ((s1 + s2 + p1 + p2)/4));
        }
        public string Durum()
        {
            int ortalama = (s1 + s2 + p1 + p2) / 4;

            if (ortalama > 49)
            {
                return string.Format("Öğrenci Bilgisi: {0}\nNo: {1}\nDurumu: Geçti", ad, no);
            }
            else 
            {
                return string.Format("Öğrenci Bilgisi: {0}\nNo: {1}\nDurumu: Kaldı", ad, no);
            }
            
        }
    }
}
