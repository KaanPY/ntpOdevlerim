﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace projeV1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            if (checkBox1.Checked)
            {
                // Açık Mod
                button1.BackColor = Color.Silver;
            }
            else
            {
                // Karanlık Mod
                button1.BackColor = Color.Gray;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString();
            label2.Text = DateTime.Now.ToLongDateString();

            timer1.Interval = 1000;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                // Açık Mod
                checkBox1.Text = "Koyu Mod";
                checkBox1.FlatAppearance.BorderColor = Color.FromName("Menu");
                checkBox1.ForeColor = Color.Black;

                // Form
                this.BackColor = Color.FromName("Menu");
                this.ForeColor = Color.Black;

                // Navigator
                button1.ForeColor = Color.Black;
                button2.ForeColor = Color.Black;
                button3.ForeColor = Color.Black;
                button8.ForeColor = Color.Black;

                button1.BackColor = Color.FromName("Menu");
                button2.BackColor = Color.FromName("Menu");
                button3.BackColor = Color.FromName("Menu");
                button8.BackColor = Color.FromName("Menu");

                button1.FlatAppearance.BorderColor = Color.FromName("Menu");
                button2.FlatAppearance.BorderColor = Color.FromName("Menu");
                button3.FlatAppearance.BorderColor = Color.FromName("Menu");
                button8.FlatAppearance.BorderColor = Color.FromName("Menu");

                if (panel1.Visible == true)
                {
                    button1.BackColor = Color.Silver;
                }
                if (panel2.Visible == true)
                {
                    button2.BackColor = Color.Silver;
                }
                if (panel3.Visible == true)
                {
                    button3.BackColor = Color.Silver;
                }
                if (panel4.Visible == true)
                {
                    button8.BackColor = Color.Silver;
                }



                // Designer By Kaan
                label7.ForeColor = Color.Black;
                label7.BackColor = Color.Silver;

                // Saat - Tarih
                label1.ForeColor = Color.FromArgb(255,128,0);
                label2.ForeColor = Color.FromName("MediumSeaGreen");

                // Sayaç
                label3.ForeColor = Color.DarkSlateGray;

                label4.ForeColor = Color.Black;
                label5.ForeColor = Color.Black;
                label6.ForeColor = Color.Black;

                numericUpDown1.BackColor = Color.FromArgb(64, 64, 64);
                numericUpDown2.BackColor = Color.FromArgb(64, 64, 64);
                numericUpDown3.BackColor = Color.FromArgb(64, 64, 64);

                numericUpDown1.ForeColor = Color.White;
                numericUpDown2.ForeColor = Color.White;
                numericUpDown3.ForeColor = Color.White;

                button4.FlatAppearance.BorderColor = Color.Blue;
                button5.FlatAppearance.BorderColor = Color.Red;
                button6.FlatAppearance.BorderColor = Color.FromArgb(255, 128, 0);

                button4.ForeColor = Color.FromArgb(64, 64, 64);
                button5.ForeColor = Color.FromArgb(64, 64, 64);
                button6.ForeColor = Color.FromArgb(64, 64, 64);

                // Kronometre
                label9.ForeColor = Color.Teal;
                label10.ForeColor = Color.FromArgb(0, 192, 192);

                checkBox2.FlatAppearance.BorderColor = Color.Blue;
                checkBox3.FlatAppearance.BorderColor = Color.Red;

                checkBox2.FlatAppearance.CheckedBackColor = Color.FromName("Menu");
                checkBox3.FlatAppearance.CheckedBackColor = Color.FromName("Menu");

                checkBox2.ForeColor = Color.FromArgb(64, 64, 64);
                checkBox3.ForeColor = Color.FromArgb(64, 64, 64);

                //Ders

                // Panel 5
                label12.ForeColor = Color.Black;

                listBox2.BackColor = Color.FromName("Menu");

            }
            else
            {
                // Karanlık Mod
                checkBox1.Text = "Açık Mod";
                checkBox1.ForeColor = Color.White;
                checkBox1.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);

                // Form
                this.BackColor = Color.FromArgb(64, 64, 64);
                this.ForeColor = Color.White;

                // Navigator
                button1.ForeColor = Color.White;
                button2.ForeColor = Color.White;
                button3.ForeColor = Color.White;
                button8.ForeColor = Color.White;

                button1.BackColor = Color.FromArgb(64, 64, 64);
                button2.BackColor = Color.FromArgb(64, 64, 64);
                button3.BackColor = Color.FromArgb(64, 64, 64);
                button8.BackColor = Color.FromArgb(64, 64, 64);

                button1.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
                button2.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
                button3.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
                button8.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);

                if (panel1.Visible == true)
                {
                    button1.BackColor = Color.Gray;
                }
                if (panel2.Visible == true)
                {
                    button2.BackColor = Color.Gray;
                }
                if (panel3.Visible == true)
                {
                    button3.BackColor = Color.Gray;
                }
                if (panel4.Visible == true)
                {
                    button8.BackColor = Color.Gray;
                }

                // Designer By Kaan
                label7.ForeColor = Color.White;
                label7.BackColor = Color.DimGray;

                // Saat - Tarih
                label1.ForeColor = Color.FromArgb(255, 192, 128);
                label2.ForeColor = Color.FromArgb(255, 255, 128);

                // Sayaç
                label3.ForeColor = Color.FromArgb(192, 255, 255);

                label4.ForeColor = Color.White;
                label5.ForeColor = Color.White;
                label6.ForeColor = Color.White;

                numericUpDown1.BackColor = Color.White;
                numericUpDown2.BackColor = Color.White;
                numericUpDown3.BackColor = Color.White;

                numericUpDown1.ForeColor = Color.Black;
                numericUpDown2.ForeColor = Color.Black;
                numericUpDown3.ForeColor = Color.Black;

                button4.FlatAppearance.BorderColor = Color.FromArgb(128, 255, 128);
                button5.FlatAppearance.BorderColor = Color.FromArgb(255, 128, 128);
                button6.FlatAppearance.BorderColor = Color.FromArgb(255, 192, 128);

                button4.ForeColor = Color.FromName("HighlightText");
                button5.ForeColor = Color.FromName("HighlightText");
                button6.ForeColor = Color.FromName("HighlightText");

                // Kronometre
                label9.ForeColor = Color.FromArgb(128, 255, 128);
                label10.ForeColor = Color.FromArgb(192, 255, 192);

                checkBox2.FlatAppearance.BorderColor = Color.FromArgb(128, 128, 255);
                checkBox3.FlatAppearance.BorderColor = Color.FromArgb(255, 128, 128);

                checkBox2.FlatAppearance.CheckedBackColor = Color.FromArgb(64, 64, 64);
                checkBox3.FlatAppearance.CheckedBackColor = Color.FromArgb(64, 64, 64);

                checkBox2.ForeColor = Color.FromName("HighlightText");
                checkBox3.ForeColor = Color.FromName("HighlightText");

                // Ders

                // Panel 5
                label12.ForeColor = Color.White;

                listBox2.BackColor = Color.FromArgb(64, 64, 64);

                listBox2.ForeColor = Color.Tomato;


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Navigator
            if (checkBox1.Checked)
            {
                // Açık Mod
                button1.BackColor = Color.Silver;
                button2.BackColor = Color.FromName("Menu");
                button3.BackColor = Color.FromName("Menu");
                button8.BackColor = Color.FromName("Menu");
            }
            else
            {
                // Karanlık Mod
                button1.BackColor = Color.Gray;
                button2.BackColor = Color.FromArgb(64, 64, 64);
                button3.BackColor = Color.FromArgb(64, 64, 64);
                button8.BackColor = Color.FromArgb(64, 64, 64);
            }

            // Slider
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Navigator
            if (checkBox1.Checked)
            {
                // Açık Mod
                button1.BackColor = Color.FromName("Menu");
                button2.BackColor = Color.Silver;
                button3.BackColor = Color.FromName("Menu");
                button8.BackColor = Color.FromName("Menu");
            }
            else
            { 
                // Karanlık Mod
                button1.BackColor = Color.FromArgb(64, 64, 64);
                button2.BackColor = Color.Gray;
                button3.BackColor = Color.FromArgb(64, 64, 64);
                button8.BackColor = Color.FromArgb(64, 64, 64);
            }

            // Slider
            panel1.Visible = false;
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Navigator
            if (checkBox1.Checked)
            {
                // Açık Mod
                button1.BackColor = Color.FromName("Menu");
                button2.BackColor = Color.FromName("Menu");
                button3.BackColor = Color.Silver;
                button8.BackColor = Color.FromName("Menu");
            }
            else
            {
                // Karanlık Mod
                button1.BackColor = Color.FromArgb(64, 64, 64);
                button2.BackColor = Color.FromArgb(64, 64, 64);
                button3.BackColor = Color.Gray;
                button8.BackColor = Color.FromArgb(64, 64, 64);
            }

            // Slider
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Navigator
            if (checkBox1.Checked)
            {
                // Açık Mod
                button1.BackColor = Color.FromName("Menu");
                button2.BackColor = Color.FromName("Menu");
                button3.BackColor = Color.FromName("Menu");
                button8.BackColor = Color.Silver;
            }
            else
            {
                // Karanlık Mod
                button1.BackColor = Color.FromArgb(64, 64, 64);
                button2.BackColor = Color.FromArgb(64, 64, 64);
                button3.BackColor = Color.FromArgb(64, 64, 64);
                button8.BackColor = Color.Gray;
            }

            // Slider
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
        }

        // Sayaç; saat - dakika - saniye Değişkenleri
        sbyte hour = 0;
        sbyte minutes = 0;
        sbyte second = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            hour = Convert.ToSByte(numericUpDown1.Value);
            minutes = Convert.ToSByte(numericUpDown2.Value);
            second = Convert.ToSByte(numericUpDown3.Value);

            // süre ayarları
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;

            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            numericUpDown3.Visible = false;

            //saya başlat
            button4.Enabled = false;

            // sayaç durdur
            button5.Visible = true;
            button5.Enabled = true;

            // sayaç devam
            button6.Visible = false;

            // süre doldu
            label3.Visible = true;
            label8.Visible = false;

            timer2.Interval = 1;
            timer2.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            string saat;
            string dakika;
            string saniye;

            // Sayaç timer
            if (hour < 10)
            {
                saat = "0" + hour.ToString();
            }
            else
            {
                saat = hour.ToString();
            }
            if (minutes < 10)
            {
                dakika = "0" + minutes.ToString();
            }
            else
            {
                dakika = minutes.ToString();
            }
            if (second < 10)
            {
                saniye = "0" + second.ToString();
            }
            else
            {
                saniye = second.ToString();
            }

            label3.Text = saat + "." + dakika + "." + saniye;

            second -= 1;
            if (hour > 0 && minutes <= 0 && second <= 0)
            {
                hour -= 1;
                minutes = 59;
                second = 60;
            }
            if (second <= 0)
            {
                minutes -= 1;
                second = 60;
            }
            if (hour <= 0 && minutes <= -1)
            {
                label3.Text = "00.00.00";
                label3.Visible = false;

                // süre doldu
                label8.Visible = true;

                // sayaç başlat
                button4.Enabled = true;

                // sayaç durdur
                button5.Visible = true;
                button5.Enabled = false;

                // sayaç devam
                button6.Visible = false;

                // süre ayarları
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;

                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                numericUpDown3.Visible = true;

                timer2.Enabled = false;
            }

            timer2.Interval = 1000;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // süre ayarları
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;

            numericUpDown1.Visible = true;
            numericUpDown2.Visible = true;
            numericUpDown3.Visible = true;

            // sayaç durdur - devam
            button5.Visible = false;
            button6.Visible = true;

            // sayaç başlat
            button4.Enabled = true;

            timer2.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // süre ayarları
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;

            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            numericUpDown3.Visible = false;

            // sayaç durdur - devam
            button5.Visible = true;
            button6.Visible = false;

            // sayaç başlat
            button4.Enabled = false;

            timer2.Enabled = true;
        }

        // Koronometre dakika - saniye - salise Değişkenleri
        sbyte minutes2 = 0;
        sbyte second2 = 0;
        sbyte salise2 = 0;
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            // Kronometre başlat - sıfırla
            if (checkBox2.Checked)
            {
                checkBox2.Text = "Sıfırla";
                checkBox2.Enabled = false;

                checkBox3.Enabled = true;

                timer3.Enabled = true;
            }
            else
            {
                minutes2 = 0;
                second2 = 0;
                salise2 = 0;

                // Kronometre Durdur - Devam
                checkBox3.Enabled = false;
                checkBox3.Checked = false;
                checkBox3.Text = "Durdur";

                // Kronometre
                label9.Text = "00.00";
                label10.Text = "00";

                // Kronometre başlat - sıfırla
                checkBox2.Text = "Başlat";
                checkBox2.Enabled = true;

                timer3.Enabled = false;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            string dakika;
            string saniye;
            string salise;

            if (minutes2 < 10)
            {
                dakika = "0" + minutes2.ToString();
            }
            else
            {
                dakika = minutes2.ToString();
            }
            if (second2 < 10)
            {
                saniye = "0" + second2.ToString();
            }
            else
            {
                saniye = second2.ToString();
            }
            if (salise2 < 10)
            {
                salise = "0" + salise2.ToString();
            }
            else
            {
                salise = salise2.ToString();
            }

            label9.Text = dakika + "." + saniye;
            label10.Text = salise;

            salise2 += 1;

            if (salise2 >= 60)
            {
                second2 += 1;
                salise2 = 0;
            }
            if (second2 >= 60)
            {
                minutes2 += 1;
                second2 = 0;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                timer3.Enabled = false;

                checkBox3.Text = "Devam";

                checkBox2.Enabled = true;
            }
            else
            {
                timer3.Enabled = true;

                checkBox3.Text = "Durdur";

                checkBox2.Enabled = false;
            }
        }

        sbyte ders = 0;
        sbyte teneffus = 0;

        byte status = 2;
        private void timer4_Tick(object sender, EventArgs e)
        {
            int dSaniye = DateTime.Now.Second;

            // Panel 5
            if (status == 0 || status == 1)
            {
                panel5.Visible = false;
            }

            // Ders - teneffüs saatleri
            int cHour = DateTime.Now.Hour;
            int cMinutes = DateTime.Now.Minute;

            if (cHour == 09 && cMinutes == 00)
            {
                label11.Text = "Ders 1";
                status = 0;
            }
            if (cHour == 09 && cMinutes == 40)
            {
                label11.Text = "1. Teneffüs";
                status = 1;
            }

            if (cHour == 09 && cMinutes == 50)
            {
                label11.Text = "Ders 2";
                status = 0;
            }
            if (cHour == 10 && cMinutes == 30)
            {
                label11.Text = "2. Teneffüs";
                status = 1;
            }

            if (cHour == 10 && cMinutes == 40)
            {
                label11.Text = "Ders 3";
                status = 0;
            }
            if (cHour == 11 && cMinutes == 20)
            {
                label11.Text = "3. Teneffüs";
                status = 1;
            }

            if (cHour == 11 && cMinutes == 30)
            {
                label11.Text = "Ders 4";
                status = 0;
            }
            if (cHour == 12 && cMinutes == 10)
            {
                label11.Text = "4. Teneffüs";
                status = 1;
            }

            if (cHour == 12 && cMinutes == 20)
            {
                label11.Text = "Ders 5";
                status = 0;
            }
            if (cHour == 13 && cMinutes == 00)
            {
                label11.Text = "5. Teneffüs";
                status = 1;
            }

            if (cHour == 13 && cMinutes == 30)
            {
                label11.Text = "Ders 6";
                status = 0;
            }
            if (cHour == 14 && cMinutes == 10)
            {
                label11.Text = "6. Teneffüs";
                status = 1;
            }

            if (cHour == 14 && cMinutes == 20)
            {
                label11.Text = "Ders 7";
                status = 0;
            }
            if (cHour == 15 && cMinutes == 00)
            {
                label11.Text = "7. Teneffüs";
                status = 1;
            }

            if (cHour == 15 && cMinutes == 10)
            {
                label11.Text = "Ders 8";
                status = 0;
            }
            if (cHour == 15 && cMinutes == 50)
            {
                label11.Text = "8. Teneffüs";
                status = 1;
            }

            if (cHour == 16 && cMinutes == 00)
            {
                label11.Text = "Ders 9";
                status = 0;
            }
            if (cHour == 16 && cMinutes == 40)
            {
                label11.Text = "Okul çıkışı..";
                status = 2;
            }

            // Ders Zaman
            if (status == 0)
            {
                teneffus = 0;

                label13.Text = "Zilin çalmasına " + (40 - ders).ToString() + "dk var";

                if (dSaniye >= 59)
                {
                    ders += 1;
                }
                if (ders >= 40)
                {
                    teneffus = 0;
                    ders = 0;

                    status = 2;
                }
            }
            else if (status == 1)
            {
                ders = 0;

                label13.Text = "Zilin çalmasına " + (10 - teneffus).ToString() + "dk var";

                if (dSaniye >= 59)
                {
                    teneffus += 1;
                }
                if (teneffus >= 10)
                {
                    ders = 0;
                    teneffus = 0;

                    status = 2;
                }
            }
            else
            {
                ders = 0;
                teneffus = 0;
            }

             timer4.Interval = 1000;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label11.Text = listBox2.SelectedItem.ToString();
            panel5.Visible = false;
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            button7.Enabled = true;
        }
    }
}
