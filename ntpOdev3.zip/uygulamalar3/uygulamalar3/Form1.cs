﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace uygulamalar3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text, userPassword = textBox2.Text;

            if(userName == "admin" && userPassword == "kaanBey1453")
            {
                groupBox1.Visible = false;
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre yanlış! Lütfen tekrar deneyiniz.", "Login Error", MessageBoxButtons.OK);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            char alphabe = Convert.ToChar(comboBox1.Text);

            switch (alphabe)
            {
                case 'A':
                case 'E':
                case 'I':
                case 'İ':
                case 'O':
                case 'Ö':
                case 'U':
                case 'Ü':
                    label8.Text = comboBox1.Text + " sesli bir harftir.";
                    label8.ForeColor = Color.Green;
                    break;
                default:
                    label8.Text = comboBox1.Text + " sessiz bir harftir.";
                    label8.ForeColor = Color.Red;
                    break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double kilo = Convert.ToDouble(textBox3.Text), boy = Convert.ToDouble(textBox4.Text), result;

            result = kilo / (boy * boy);

            if (result < 18.49)
            {
                label11.Text = "İdeal Kilonun Altı";
                label11.ForeColor = Color.Tomato;
            }
            else if (result >= 18.5 && result <= 24.99)
            {
                label11.Text = "İdeal Kilo";
                label11.ForeColor = Color.Green;
            }
            else if (result >= 25 && result <= 29.99)
            {
                label11.Text = "İdeal Kilonun Üzeri";
                label11.ForeColor = Color.Orange;
            }
            else if (result >= 30)
            {
                label11.Text = "İdeal Kilonun Çok Üzeri";
                label11.ForeColor = Color.Red;
            }
            else
            {
                label11.Text = "Lütfen geçerli kilo ve boy giriniz";
                label11.ForeColor = Color.Yellow;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            byte number = Convert.ToByte(textBox5.Text), number2 = Convert.ToByte(textBox6.Text), number3 = Convert.ToByte(textBox7.Text);
            string buyuk;

            if (number == number2 && number == number3 && number2 == number && number2 == number3 && number3 == number && number3 == number2)
            {
                label15.Text = "Sayılar Eşittir";
            }
            else
            {
                if (number > number2 && number > number3)
                {
                    buyuk = number.ToString() + " En Büyük";
                }
                else if (number2 > number && number2 > number3)
                {
                    buyuk = number2.ToString() + " En Büyük";
                }
                else
                {
                    buyuk = number3.ToString() + " En Büyük";
                }


                if (number < number2 && number < number3)
                {
                    label15.Text = buyuk + "\n" + number.ToString() + " En Küçük";
                }
                else if (number2 < number && number2 < number3)
                {
                    label15.Text = buyuk + "\n" + number2.ToString() + " En Küçük";
                }
                else
                {
                    label15.Text = buyuk + "\n" + number3.ToString() + " En Küçük";
                }
            }

        }
    }
}
