﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GelistirilmisSaat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = DateTime.Now.ToLongTimeString();
            label9.Text = DateTime.Now.ToLongDateString();

            timer1.Interval = 1000;
        }

        int hour = 0;
        int minutes = 0;
        int second = 0;

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (hour < 10)
            {
                label3.Text = "0" + hour.ToString();
            }
            else
            {
                label3.Text = hour.ToString();
            }
            if (minutes < 10)
            {
                label4.Text = "0" + minutes.ToString();
            }
            else
            {
                label4.Text = minutes.ToString();
            }
            if (second < 10)
            {
                label5.Text = "0" + second.ToString();
            }
            else
            {
                label5.Text = second.ToString();
            }

            //label3.Text = hour.ToString();
            //label4.Text = minutes.ToString();
            //label5.Text = second.ToString();

            second -= 1;

            if (second <= 0)
            {
                minutes -= 1;
                second = 60;
            }
            if(hour > 0 && minutes <= 0)
            {
                hour -= 1;
                minutes = 59;
                second = 60;
            }
            if (hour <= 0 && minutes <= -1)
            {
                label3.Text = "00";
                label4.Text = "00";
                label5.Text = "00";

                second = 0;
                minutes = 0;
                hour = 0;

                button5.Visible = true;

                label6.Visible = true;
                label7.Visible = true;
                label8.Visible = true;

                numericUpDown1.Visible = true;
                numericUpDown2.Visible = true;
                numericUpDown3.Visible = true;

                button3.Enabled = true;
                button4.Enabled = false;

                timer2.Enabled = false;
            }
            timer2.Interval = 1000;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // BAŞLAT

            button5.Visible = false;

            button4.Visible = true;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;

            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            numericUpDown3.Visible = false;

            button3.Enabled = false;
            button4.Enabled = true;

            hour = Convert.ToInt32(numericUpDown1.Value);
            minutes = Convert.ToInt32(numericUpDown2.Value);
            second = Convert.ToInt32(numericUpDown3.Value);

            timer2.Enabled = true;
            timer2.Interval = 10;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            // DURDUR
            timer2.Enabled = false;

            button4.Visible = false;

            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;

            numericUpDown1.Visible = true;
            numericUpDown2.Visible = true;
            numericUpDown3.Visible = true;

            button5.Visible = true;
            button3.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // DEVAM ETTİR

            timer2.Enabled = true;

            button4.Visible = true;

            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;

            numericUpDown1.Visible = false;
            numericUpDown2.Visible = false;
            numericUpDown3.Visible = false;

            button5.Visible = false;
            button3.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
            panel3.Visible = false;
            panel2.Visible = false;

            pictureBox2.Location = new Point(14, 206);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
            panel3.Visible = true;
            panel2.Visible = false;

            pictureBox2.Location = new Point(14, 250);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            panel4.Visible = false;
            panel3.Visible = false;
            panel2.Visible = true;

            pictureBox2.Location = new Point(14, 293);
        }

        int minutes2 = 0;
        int second2 = 0;
        int salise = 0;
        private void button10_Click(object sender, EventArgs e)
        {
            // BAŞLAT
            timer3.Enabled = true;

            button9.Visible = true;
            button11.Visible = false;

            button8.Enabled = true;
            button9.Enabled = false;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (minutes2 < 10)
            {
                label13.Text = "0" + minutes2.ToString();
            }
            else
            {
                label13.Text = minutes2.ToString();
            }
            if (second2 < 10)
            {
                label14.Text = "0" + second2.ToString();
            }
            else
            {
                label14.Text = second2.ToString();
            }
            if (salise < 10)
            {
                label15.Text = "0" + salise.ToString();
            }
            else
            {
                label15.Text = salise.ToString();
            }

            salise += 1;
            if (salise >= 60)
            {
                second2 += 1;
                salise = 0;
            }
            if (second2 >= 60)
            {
                minutes2 += 1;
                second2 = 0;
                salise = 0;
            }
            if (minutes2 >= 60)
            {
                timer3.Enabled = false;
            }

        }

        private void button9_Click(object sender, EventArgs e)
        { 
            // SIFIRLA
            minutes2 = 0;
            second2 = 0;
            salise = 0;

            label13.Text = "00";
            label14.Text = "00";
            label15.Text = "00";

            button8.Visible = true;
            button9.Visible = false;
            button11.Visible = false;
            button10.Visible = true;

            button8.Enabled = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // DURDUR

            timer3.Enabled = false;
            button9.Enabled = true;

            button11.Visible = true;
            button8.Visible = false;
            button10.Visible = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // DEVAM
            button11.Visible = false;
            button8.Visible = true;

            button9.Enabled = false;
            timer3.Enabled = true;
        }
    }
}
